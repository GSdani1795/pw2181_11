<?php
	for ($i=0; $i < 10 ; $i++) { 
?>
 Hola PHP
<?php
	}
?>