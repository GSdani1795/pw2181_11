<?php
function conecta(){


$con= mysql_connect();


}